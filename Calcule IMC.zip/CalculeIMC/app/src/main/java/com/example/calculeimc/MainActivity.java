package com.example.calculeimc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calcularIMC(View view) {
        double peso = Double.parseDouble(inputPeso.getText().toString());
        double altura = Double.parseDouble(inputAltura.getText().toString());
        double imc = peso / (altura * altura);
    }
}




